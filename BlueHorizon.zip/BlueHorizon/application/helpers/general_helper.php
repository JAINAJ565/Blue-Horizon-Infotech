<?php
	if ( !function_exists('get_status') ) {
		function get_status( $key  = 0) {
			$st_arr = array(
				1 => 'Active',
				2 => 'Inactive'
			);
			return $st_arr[$key];
		}
	}
?>
