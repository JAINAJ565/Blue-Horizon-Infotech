<div class="container">
	<h1>Add Time Entry</h1>
	<div class="row col-md-6">
		<form action="" method="post">
			<div class="row">
			<div class="form-group col-md-6 <?php echo form_error('project_id')?'has-error':'';?>">
				<label for="project_id">Project:</label>
				<select class="form-control" id="project_id" name="project_id">
					<option value="">Select</option>
					<?php foreach($projects as $project ){ ?>
					<option <?php if($row['project_id'] == $project->project_id){ echo "selected=seleted"; } ?> value="<?php echo $project->project_id; ?>"><?php echo $project->project_name; ?></option>
					<?php } ?>
				</select>
				<?php echo form_error('project_id');?>
			</div>
			<div id="task_selects">
			<div class="form-group col-md-6 <?php echo form_error('task_id')?'has-error':'';?>">
				<label for="task_id">Task:</label>
				<select class="form-control" id="task_id" name="task_id">
					<option value="">Select</option>
				</select>
				<?php echo form_error('task_id');?>
			</div>
			</div>
			</div>
			<div class="row">
			<div class="form-group col-md-6 <?php echo form_error('time_hours')?'has-error':'';?>">
				<label for="time_hours">Hours:</label>
				<input type="number" class="form-control" id="time_hours" min=0 name="time_hours" value="<?php echo $row['time_hours'];?>">
				<?php echo form_error('time_hours');?>
			</div>
			<div class="form-group col-md-6 <?php echo form_error('time_date')?'has-error':'';?>">
				<label for="time_date">Date:</label>
				<input type="date" class="form-control" id="time_date" name="time_date" value="<?php echo $row['time_date'];?>">
				<?php echo form_error('time_date');?>
			</div>
			</div>
			<div class="row">
			<div class="form-group col-md-12 <?php echo form_error('time_description')?'has-error':'';?>">
  				<label for="time_description">Description:</label>
  				<textarea class="form-control" rows="5" id="time_description" name="time_description"><?php echo $row['time_description'];?></textarea>
				<?php echo form_error('time_description');?>
			</div></div>
			<button type="submit" class="btn btn-default">Submit</button>
			</form>
		</form>
	</div>
</div>
