<div class="container">
	<h1>Manage Projects</h1>
	<div class="row">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>SNo</th>
					<th>Project Name</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
				<?php $i=1;
				 foreach($projects as $project){ ?>
				<tr>
					<td><?php echo $i++; ?></td>
					<td><?php echo $project->project_name; ?></td>
					<td><?php echo get_status($project->project_status); ?></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</div>
