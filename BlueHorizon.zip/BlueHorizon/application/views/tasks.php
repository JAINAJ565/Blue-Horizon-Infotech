<div class="container">
	<h1>Manage Tasks</h1>
	<div class="row">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>SNo</th>
					<th>Project Name</th>
					<th>Task Name</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
				<?php $i=1;
				foreach($tasks as $task){ ?>
				<tr>
					<td><?php echo $i++; ?></td>
					<td><?php echo $task->project_name; ?></td>
					<td><?php echo $task->task_name; ?></td>
					<td><?php echo get_status($task->task_status); ?></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</div>
