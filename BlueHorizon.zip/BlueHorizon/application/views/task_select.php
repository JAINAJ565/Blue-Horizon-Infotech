<div class="form-group col-md-6 <?php echo form_error('task_id')?'has-error':'';?>">
				<label for="task_id">Task:</label>
				<select class="form-control" id="task_id" name="task_id">
					<option value="">Select</option>
					<?php foreach($tasks as $task ){ ?>
					<option value="<?php echo $task->task_id; ?>"><?php echo $task->task_name; ?></option>
					<?php } ?>
				</select>
				<?php echo form_error('task_id');?>
			</div>
