<div class="container">
	<?php if($this->session->flashdata('msg')){?>   
		<div class="alert alert-success">
			<button class="close" data-close="alert">X</button>
			<span><?php echo $this->session->flashdata('msg');?></span>
		</div>
	<?php }?>
	<h1>Time Entry <a href="<?php echo site_url('time/add');?>" > <button class="btn"> Add </button></a></h1>
	<div class="row">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>SNo</th>
					<th>Project Name</th>
					<th>Task Name</th>
					<th>Hours</th>
					<th>Date</th>
					<th>Description</th>
				</tr>
			</thead>
			<tbody>
				<?php $i=1;
				foreach($time as $time){ ?>
				<tr>
					<td><?php echo $i++; ?></td>
					<td><?php echo $time->project_name; ?></td>
					<td><?php echo $time->task_name; ?></td>
					<td><?php echo $time->time_hours; ?></td>
					<td><?php echo $time->time_date != NULL ? date('d/m/Y',strtotime($time->time_date)):''; ?></td>
					<td><?php echo $time->time_description; ?></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</div>
