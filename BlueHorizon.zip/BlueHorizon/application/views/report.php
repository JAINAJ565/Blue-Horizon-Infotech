<div class="container">
	<h1>Report</h1>
	<form>
		<div class="form-group col-md-6">
			<input id="search" class="form-control" type="text" placeholder="Search Project" name="search"/>
		</div>
		
	</form>

	<div class="row">
		<table id="table" class="table table-bordered">
			<thead>
				<tr>
					<th>SNo</th>
					<th>Name</th>
					<th>Total Hours</th>
				</tr>
			</thead>
			<?php $i=1; $project='';$sub_total=0;
				foreach($time as $times){
				if($project!=$times->project_id){
					$i++;
					$sub_total=0;
				}
					$project = $times->project_id;
					$sub_total+=$times->t_time;
					$araytotal[$i]=$sub_total;
					}
				?>
			<tbody>
				<?php $i=1; $project='';$sub_total=0;
				foreach($time as $time){
				if($project!=$time->project_id){
				?>

				<tr>
					<th><?php echo $i++; ?></th>
					<th><?php echo $time->project_name; ?></th>
					<th><?php echo $araytotal[$i]; ?></th>
				</tr>
				<?php }  ?>
				<tr>
					<td></td>
					<td><?php echo $time->task_name; ?></td>
					<td><?php echo $time->t_time; ?></td>
				</tr>
				<?php
					$project = $time->project_id;
					}
				 ?>
				 
			</tbody>
		</table>
	</div>
</div>
