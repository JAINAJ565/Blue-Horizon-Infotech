
<!-- Latest compiled and minified JavaScript -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script type="text/javascript">
$(document).ready(function(){
	loadtask();
	$('#project_id').on('change length',function(){
		loadtask();
	});
	$('#search').on('keyup length ',function(){
		search();
	});

}); 
function loadtask(){
	var val = $('#project_id').val();
	$.ajax({
			type: 'post',
			url: 'tasks',
			datatype:'json',
			data: {project_id:val},
			success: function (response) {
				$('#task_selects').html(response);
			}
		});
}
function search(){
	var val = $('#search').val();
	$.ajax({
			type: 'post',
			url: 'search',
			datatype:'json',
			data: {search:val},
			success: function (response) {
				$('#table').html(response);
			}
		});
}

</script>
</boby>
</html>
