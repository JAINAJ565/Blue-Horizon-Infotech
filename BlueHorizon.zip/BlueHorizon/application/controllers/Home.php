<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	
	public function index()
	{
		$this->load->view('header');
		$this->load->view('home');
		$this->load->view('footer');
	}

	public function projects()
	{
		$this->data['projects'] = $this->common->get_all( 'projects');
		$this->load->view('header');
		$this->load->view('projects', $this->data);
		$this->load->view('footer');
	}
	public function tasks()
	{
		$this->data['tasks'] = $this->common->get_all( 'tasks t',array('p.project_status' => 1),'t.*,p.project_name','','','',array('projects p' => 'p.project_id = t.project_id'));
		$this->load->view('header');
		$this->load->view('tasks',$this->data);
		$this->load->view('footer');
	}
	public function time()
	{
		$this->data['time'] = $this->common->get_all( 'time ti',array('p.project_status' => 1, 't.task_status'=>1),'ti.*,p.project_name,t.task_name','','','',array('tasks t' => 't.task_id = ti.task_id','projects p' => 'p.project_id = t.project_id'));
		$this->load->view('header');
		$this->load->view('time',$this->data);
		$this->load->view('footer');
	}
	public function report()
	{
		$this->data['time'] = $this->common->get_all( 'time ti',array('p.project_status' => 1, 't.task_status'=>1),'p.project_id,p.project_name,t.task_name,sum(ti.time_hours) as t_time ','p.project_name,t.task_name','','',array('tasks t' => 't.task_id = ti.task_id','projects p' => 'p.project_id = t.project_id'),'','ti.task_id');
		$this->load->view('header');
		$this->load->view('report',$this->data);
		$this->load->view('footer');
	}
	public function time_add()
	{
		$this->data['projects'] = $this->common->get_all( 'projects',array('project_status'=>1));
		$this->data['row'] = array(
			'project_id'=>'',
			'task_id'=>'',
			'time_hours'=>'',
			'time_date'=>'',
			'time_description'=>'',
		);	

		$this->form_validation->set_message('required', '%s is required.');
		$this->form_validation->set_rules('project_id', 'Project', 'trim|required');
		$this->form_validation->set_rules('task_id', 'Task', 'trim|required');
		$this->form_validation->set_rules('time_hours', 'Hours', 'trim|required');
		$this->form_validation->set_rules('time_date', 'Date', 'trim|required');
		$this->form_validation->set_rules('time_description', 'Description', 'trim|required');
		$this->form_validation->set_error_delimiters('<span class="help-block">', '</span>');
		
		if($_POST){
			if( $this->form_validation->run() == false ){
				$this->data['row'] = array_merge( $this->data['row'], $_POST );
			}else{
				$data_arr = array(
					'task_id'=> trim($this->input->post('task_id')),
					'time_hours'=> trim($this->input->post('time_hours')),
					'time_date'=> trim($this->input->post('time_date')),
					'time_description'=> trim($this->input->post('time_description')),
				);
				$id = $this->common->insert( 'time', $data_arr );
				$this->session->set_flashdata('msg','Time Entered');
				redirect('time');
			}

		}
		$this->load->view('header');
		$this->load->view('time_add',$this->data);
		$this->load->view('footer');
	}
	public function time_task()
	{
		if($_POST){
		$project_id = trim($this->input->post('project_id'));
		$this->data['tasks'] = $this->common->get_all( 'tasks',array('task_status' => 1, 'project_id' => $project_id ));
		$this->load->view('task_select',$this->data);
		}
	}
	public function search()
	{
		if($_POST){
		$search = trim($this->input->post('search'));
		$this->data['time'] = $this->common->get_all( 'time ti','p.project_status = 1 AND t.task_status = 1 AND p.project_name LIKE "%'.$search.'%"','p.project_id,p.project_name,t.task_name,sum(ti.time_hours) as t_time ','p.project_name,t.task_name','','',array('tasks t' => 't.task_id = ti.task_id','projects p' => 'p.project_id = t.project_id'),'','ti.task_id');
		$this->load->view('search',$this->data);
		}
	}
}
