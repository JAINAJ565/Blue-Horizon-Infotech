<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Common extends CI_Model{
   
    function insert( $table = '',$data = array() ) {
		$this->db->insert($table,$data);
		return $this->db->insert_id();
	}
	
	function get_all( $table = '',$condition = array(),$select = '',$order_by = '', $limit = 0, $offset = 0, $join_arr_left = '', $join_arr = '',$group_by = '' ) {
		if(!empty($condition))
			$this->db->where($condition);
		if($select)	
			$this->db->select($select,false);
		if($order_by)	
			$this->db->order_by($order_by);
		
		if($group_by)	
			$this->db->group_by($group_by);
		
		if($limit)
			$this->db->limit($limit,$offset);

		if( $join_arr_left ) {
			foreach( $join_arr_left as $tbl => $cond ) {
				$this->db->join( $tbl, $cond, 'left');
			}
		}
		if( $join_arr ) {
			foreach( $join_arr as $tbl => $cond ) {
				$this->db->join( $tbl, $cond);
			}
		}	
		$query = $this->db->get($table);

		return $query->result();	
	}
}
